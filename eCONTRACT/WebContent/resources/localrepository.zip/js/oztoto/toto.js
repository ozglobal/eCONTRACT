if(typeof _oz_interface_=='undefined'){
	_ozexec_=function(category,name, args){
		__ozexec_result=undefined;
		try {
			var req=new XMLHttpRequest();
			req.open('GET',  '/!ozexec', false);
			req.setRequestHeader("category", category);
			req.setRequestHeader("name", name);
			req.setRequestHeader("args", JSON.stringify(args));
			req.send(null);
		}catch(e){}
		return __ozexec_result;
	};
} else {
	_ozexec_=function(category,name, args){
		return eval(_oz_interface_.exec(category,name,JSON.stringify(args)));
	};
}
TotoObject=function(){this._events={};};
TotoObject.prototype.addEventListener=function(eventName,callback){
	var events=this._events[eventName];
	if(events == null){
		events=[];
		this._events[eventName]=events;
	}
	events.push(callback);
};
TotoObject.prototype.dispatchEvent=function(eventName,args){
	event=document.createEvent('Event');
	event.handled = false;
	if(args!=null)for(var k in args)event[k]=args[k];
	var events=this._events[eventName];
	try{
		if (events != null) {
			for(var i=0;i<events.length;i++){
				var handler=events[i];
				if(typeof handler=='function')handler(event);
				else(0,eval)(handler);
			}
		}
	}finally{
		_ozexec_("oz$","__setLastEvent",[event]);
	}
	return event;
};
//oz
oz=new TotoObject();
oz.__referenceTime__=new Date().getTime();
oz.__initialized=false;
oz.__modules__={};
oz.__history={back:window.history.back,forward:window.history.forward,go:window.history.go,};
window.history.go=function(n){_ozexec_("oz$history","go",[n]);return oz.__history.go.apply(window.history,n);}
window.history.forward=function(){_ozexec_("oz$history","forward",[]);return oz.__history.forward.apply(window.history);}
window.history.back=function(){_ozexec_("oz$history","back",[]);return oz.__history.back.apply(window.history);}
oz.init=function(url,modules,ready){
	if(oz.__initialized) throw new Error("Toto Already initialized.");
	oz.__initialized=true;
	var moduleStack=[];for(var i=0;i<modules.length;i++)moduleStack.push(modules[i]);
	var load=function(){
		if(moduleStack.length==0){if(typeof ready=='function')ready();else (0,eval)(ready);}
		else oz.require(url+moduleStack.pop(),load);
	};
	load();
};
oz.require=function(url,ready){
	if(url in oz.__modules__){
		if(ready!=null){
			var loaded=oz.__modules__[url];
			if(typeof loaded=='boolean')ready();
			else loaded.push(ready);
		}
	} else {
		var loaded=[function(){console.debug("[toto]load module: "+url)}];
		oz.__modules__[url]=loaded;
		var script=document.createElement('script');
		script.setAttribute("type","text/javascript");
		script.setAttribute("src", url);
		if(ready!=null) loaded.push(ready);
		script.onload=function(){
			oz.__modules__[url]=true;
			for(var i=0;i<loaded.length;i++)loaded[i]();
		};
		document.getElementsByTagName("head")[0].appendChild(script);
	}
};
oz.setWebViewContentHeight=function(px){return _ozexec_("oz","setWebViewContentHeight", [px]);};
oz.exit=function(){return _ozexec_("oz","exit", []);};
//oz.environment
oz.environment=new TotoObject();
oz.environment.isOnline=function(){return _ozexec_("oz.environment","isOnline", []);};
//oz.device
oz.device=new TotoObject();
oz.device.getOSName=function(){return _ozexec_("oz.device","getOSName", []);};
oz.device.getOSVersion=function(){return _ozexec_("oz.device","getOSVersion", []);};
oz.device.getModelName=function(){return _ozexec_("oz.device","getModelName", []);};
oz.device.getUUID=function(){return _ozexec_("oz.device","getUUID", []);};
oz.device.getDeviceName=function(){return _ozexec_("oz.device","getDeviceName", []);};
oz.device.getManufacturer=function(){return _ozexec_("oz.device","getManufacturer", []);};
oz.device.getBrand=function(){return _ozexec_("oz.device","getBrand", []);};

//oz.service
oz.service=new TotoObject();
//oz.service.push
oz.service.push=new TotoObject();
oz.service.push.events=["messageArrived"];
oz.service.push.available=function(){return _ozexec_("oz.service.push","available", []);};
oz.service.push.getServiceId=function(){return _ozexec_("oz.service.push","getServiceId", []);};
oz.service.push.getId=function(){return _ozexec_("oz.service.push","getId", []);};
//oz.storage
oz.storage=new TotoObject();
oz.storage.get=function(categoryName,key){return _ozexec_("oz.storage","get",[categoryName,key]);};
oz.storage.put=function(categoryName,key,value){return _ozexec_("oz.storage","put",[categoryName,key,value]);};
oz.storage.remove=function(categoryName,key){return _ozexec_("oz.storage","remove",[categoryName,key]);};
oz.storage.contains=function(categoryName,key){return _ozexec_("oz.storage","contains",[categoryName,key]);};
oz.storage.listKeys=function(categoryName){return _ozexec_("oz.storage","listKeys",[categoryName]);};
oz.storage.containsCategory=function(categoryName){return _ozexec_("oz.storage","containsCategory",[categoryName]);};
oz.storage.removeCategory=function(categoryName){return _ozexec_("oz.storage","removeCategory",[categoryName]);};
oz.storage.listCategories=function(){return _ozexec_("oz.storage","listCategories",[]);};
//oz.notification
oz.notification=new TotoObject();
oz.notification.push=function(title,message){return _ozexec_("oz.notification","push",[title,message]);};
//oz.navigator
oz.navigator=new TotoObject();
oz.navigator.events=["action"];
oz.navigator.home=new TotoObject();
oz.navigator.home.action=function(){if(!oz.navigator.dispatchEvent("action",{button:"back"}).handled) {location.href=oz.navigator.home.getUrl();}};
oz.navigator.home.getUrl=function(){return _ozexec_("oz.navigator.home","getUrl",[]);};
oz.navigator.back=new TotoObject();
oz.navigator.back.action=function(){if(!oz.navigator.dispatchEvent("action",{button:"back"}).handled){if(oz.navigator.back.available())history.back();else oz.exit();}};
oz.navigator.back.available=function(){return _ozexec_("oz.navigator.back","available", []);};
oz.navigator.forward=new TotoObject();
oz.navigator.forward.action=function(){if(!oz.navigator.dispatchEvent("action",{button:"forward"}).handled){if(oz.navigator.forward.available())history.forward();}};
oz.navigator.forward.available=function(){return _ozexec_("oz.navigator.forward","available", []);};
oz.navigator.refresh=new TotoObject();
oz.navigator.refresh.action=function(){if(!oz.navigator.dispatchEvent("action",{button:"refresh"}).handled)location.reload(true);};
oz.navigator.menu=new TotoObject();
oz.navigator.menu.setVisible=function(value){return _ozexec_("oz.navigator.menu","setVisible",[value]);};
oz.navigator.menu.isVisible=function(){return _ozexec_("oz.navigator.menu","isVisible", []);};
oz.navigator.menu.action=function(){oz.navigator.dispatchEvent("action",{button:"menu"});};

window.addEventListener("unload",function(){_ozexec_("oz$","__unloaded", []);});
_ozexec_("oz$","__loadComplete", []);