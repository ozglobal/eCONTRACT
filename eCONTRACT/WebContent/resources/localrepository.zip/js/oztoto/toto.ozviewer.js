/* OZ Report Viewer for Toto Framework */
oz.viewer=new TotoObject();
oz.viewer.createViewer=function(viewerTarget,param,delimiter){return _ozexec_("oz.viewer","createViewer",["OZViewer",viewerTarget,param,delimiter,"close"]);};
oz.viewer.createReportEx=function(param,delimiter){return _ozexec_("oz.viewer","CreateReportEx",[param,delimiter]);};
oz.viewer.newReport=function(param,delimiter){return _ozexec_("oz.viewer","NewReport",[param,delimiter]);};
oz.viewer.setCloseMessage=function(msg){return _ozexec_("oz.viewer","setCloseMessage",[msg]);};
oz.viewer.setTarget=function(target){return _ozexec_("oz.viewer","setTarget",[target]);};
oz.viewer.setVisible=function(isVisible){return _ozexec_("oz.viewer","setVisible",[isVisible]);};
oz.viewer.isVisible=function(){return _ozexec_("oz.viewer","isVisible",[]);};
oz.viewer.dispose=function(){return _ozexec_("oz.viewer","Dispose",[]);};
oz.viewer.rebind=function(nIndex,type,param,delimiter){	return _ozexec_("oz.viewer","ReBind",[nIndex,type,param,delimiter]);};
oz.viewer.getInformation=function (item){return _ozexec_("oz.viewer","GetInformation",[item]);};
oz.viewer.script=function(str){return _ozexec_("oz.viewer","Script",[str]);};
oz.viewer.scriptEx=function(cmd,param,delimiter){return _ozexec_("oz.viewer","ScriptEx",[cmd,param,delimiter]);};
oz.viewer.setHelpURL=function(helpURL){return _ozexec_("oz.viewer","setHelpURL",[helpURL]);};
oz.viewer.updateSize=function(){return _ozexec_("oz.viewer","updateSize",[]);};
oz.viewer.document=Object.create(TotoObject.prototype);
oz.viewer.document.setChartStyle=function(style){return _ozexec_("oz.viewer.document","SetChartStyle",[style]);};
oz.viewer.document.pingOZServer=function(ipOrUrl,port){return _ozexec_("oz.viewer.document","PingOZServer",[ipOrUrl,port]);};
oz.viewer.document.getGlobal=function(key,nIndex){return _ozexec_("oz.viewer.document","GetGlobal",[key,nIndex]);};
oz.viewer.document.setGlobal=function(key,varValue,nIndex){return _ozexec_("oz.viewer.document","SetGlobal",[key,varValue,nIndex]);};
oz.viewer.document.getTitle=function(){return _ozexec_("oz.viewer.document","GetTitle",[]);};
oz.viewer.document.getPaperWidth=function(){return _ozexec_("oz.viewer.document","GetPaperWidth",[]);};
oz.viewer.document.getPaperHeight=function(){return _ozexec_("oz.viewer.document","GetPaperHeight",[]);};
oz.viewer.document.triggerExternalEvent=function(param1, param2, param3, param4){return _ozexec_("oz.viewer.document","TriggerExternalEvent",[param1, param2, param3, param4]);};
oz.viewer.document.triggerExternalEventByDocIndex=function(docIndex, param1, param2, param3, param4){return _ozexec_("oz.viewer.document","TriggerExternalEventByDocIndex",[docIndex, param1, param2, param3, param4]);};

