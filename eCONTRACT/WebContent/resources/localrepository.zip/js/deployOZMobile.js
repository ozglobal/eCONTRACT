if(typeof _oz_interface_=='undefined'){
	_ozexec_ = function(category,name, args){
		__ozexec_result = undefined;
		try {
			var req = new XMLHttpRequest();
			req.open('GET',  '/!ozexec', false);
			req.setRequestHeader("category", category);
			req.setRequestHeader("name", name);
			req.setRequestHeader("args", JSON.stringify(args));
			req.send(null);
		}catch(e) {}
		return __ozexec_result;
	};
} else {
	_ozexec_ = function(category,name, args){
		return eval(_oz_interface_.exec(category,name,JSON.stringify(args)));
	};
}

oz = { referenceTime:new Date().getTime() };

oz.environment = {
	isOnline:function(){return _ozexec_("oz.environment","isOnline", []);},
};

oz.viewer = {
	createViewer:function(viewerTarget, str_param, str_delimiter) { var _closeMessage = "close"; return _ozexec_("oz.viewer","createViewer", ["OZViewer", viewerTarget, str_param, str_delimiter, _closeMessage]);},
	createReportEx:function(str_param, str_delimiter) {return _ozexec_("oz.viewer","CreateReportEx", [str_param, str_delimiter]);},
	newReport:function(str_param, str_delimiter) {return _ozexec_("oz.viewer","NewReport", [str_param, str_delimiter]);},
	setCloseMessage:function(msg) {return _ozexec_("oz.viewer","setCloseMessage", [msg]);},
	setTarget:function(target) {return _ozexec_("oz.viewer","setTarget", [target]);},
	setVisible:function(isVisible) {return _ozexec_("oz.viewer","setVisible", [isVisible]);},
	isVisible:function(){return _ozexec_("oz.viewer","isVisible", []);},
	dispose:function(){return _ozexec_("oz.viewer","Dispose", []);},
	rebind:function(nIndex,str_type, str_param, str_delimiter) {	return _ozexec_("oz.viewer","ReBind", [nIndex, str_type, str_param, str_delimiter]);},
	getInformation:function (str_item) {return _ozexec_("oz.viewer","GetInformation", [str_item]);},
	script:function(str) {return _ozexec_("oz.viewer","Script", [str]);},
	scriptEx:function(str_cmd, str_param, str_delimiter) {return _ozexec_("oz.viewer","ScriptEx", [str_cmd, str_param, str_delimiter]);},
	setHelpURL:function(helpURL) {return _ozexec_("oz.viewer","setHelpURL", [helpURL]);},
	userEventCallback:function(result) {return _ozexec_("oz.viewer","userEventCallback", [result]);},
	willChangeIndex_PagingCallback:function(result) {return _ozexec_("oz.viewer","willChangeIndex_PagingCallback", [result]);},
	updateSize:function() {return _ozexec_("oz.viewer","updateSize", []);},
	document:{
		setChartStyle:function(style) {return _ozexec_("oz.viewer.document","SetChartStyle", [style]);},
		pingOZServer:function(str_ipOrUrl, port) {return _ozexec_("oz.viewer.document","PingOZServer", [str_ipOrUrl, port]);},
		getGlobal:function(key, nIndex) {return _ozexec_("oz.viewer.document","GetGlobal", [key, nIndex]);},
		setGlobal:function(key, varValue, nIndex) {return _ozexec_("oz.viewer.document","SetGlobal", [key, nIndex]);},
		getTitle:function() {return _ozexec_("oz.viewer.document","GetTitle", []);},
		getPaperWidth:function() {return _ozexec_("oz.viewer.document","GetPaperWidth", []);},
		getPaperHeight:function() {return _ozexec_("oz.viewer.document","GetPaperHeight", []);},
	},
};

oz.device = {
	getOSName:function() {return _ozexec_("oz.device","getOSName", []);},
	getOSVersion:function() {return _ozexec_("oz.device","getOSVersion", []);},
	getModelName:function() {return _ozexec_("oz.device","getModelName", []);},
	getUUID:function() {return _ozexec_("oz.device","getUUID", []);},
};
oz.service = {
	push:{
		available:function(){return _ozexec_("oz.service.push","available", []);},
		getServiceId:function(){return _ozexec_("oz.service.push","getServiceId", []);},
		getId:function(){return _ozexec_("oz.service.push","getId", []);},
		register:function(callback){ return _ozexec_("oz.service.push","register", [oz._function.add(callback)]);},
	},
};

oz.storage = {
	get:function(categoryName,key){return _ozexec_("oz.storage","get",[categoryName,key]);},
	put:function(categoryName,key,value){return _ozexec_("oz.storage","put",[categoryName,key,value]);},
	remove:function(categoryName,key){return _ozexec_("oz.storage","remove",[categoryName,key]);},
	contains:function(categoryName,key){return _ozexec_("oz.storage","contains",[categoryName,key]);},
	listKeys:function(categoryName){return _ozexec_("oz.storage","listKeys",[categoryName]);},
	containsCategory:function(categoryName){return _ozexec_("oz.storage","containsCategory",[categoryName]);},
	removeCategory:function(categoryName){return _ozexec_("oz.storage","removeCategory",[categoryName]);},
	listCategories:function(){return _ozexec_("oz.storage","listCategories",[]);},
};

oz.notification = {
	push:function(title,message){return _ozexec_("oz.notification","push",[title,message]);},
};

oz.toolbar = {
	menu: {
		setVisible:function(value){return _ozexec_("oz.toolbar.menu","setVisible",[value]);},
		isVisible:function(){return _ozexec_("oz.toolbar.menu","isVisible", []);},
		setOnClick:function(callback){return _ozexec_("oz.toolbar.menu","setOnClick", [oz._function.add(callback)]);},
	},
};

oz._function = {
	idSequence:0,
	table: {
	},
	add:function(func){
		var s = oz._function.idSequence++;
		var id = oz.referenceTime+":"+s+":"+new Date().getTime();
		oz._function.table[id] = func;
		return id;
	},
	remove:function(id){
		delete oz._function.table[id];
	},
	invoke:function(id, args){
		var f=oz._function.table[id];
		if(f!=null)
			return f.apply(null, args);
	},
};