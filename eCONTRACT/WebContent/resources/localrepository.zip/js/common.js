var isMobile = {
    Android: function() {
        return /Android/i.test(navigator.userAgent);
    },
    BlackBerry: function() {
        return /BlackBerry/i.test(navigator.userAgent);
    },
    iOS: function() {
        return /iPhone|iPad|iPod/i.test(navigator.userAgent);
    },
    Windows: function() { 
        return /IEMobile/i.test(navigator.userAgent);
    },
    any: function() {
        return (isMobile.Android() || isMobile.BlackBerry() || isMobile.iOS() || isMobile.Windows());
    }
};

function sleep(delay) {
    var start = new Date().getTime();
    while (new Date().getTime() < start + delay);
}

function addnotibar(title,message){
	var _message = message.split("<br>")[0];
	oz.notification.push(title,_message);
}

function initnoti(initializer){
	oz.init("./resources/js/oztoto/",["toto.ozviewer.js"],function(){ 
		var height = document.getElementById('ozdiv').clientHeight; 
		oz.setWebViewContentHeight(height);
		// ����Ʈ ��� �⺻ ����
		oz.viewer.addEventListener("close", function(){
			// event:close
			// �� ����Ǹ� ȣ��ȴ�.
			//history.back();
			//console.debug('oz.viewer.close.1');
		});
		
		oz.viewer.addEventListener("OZPostCommand", function(event){
			//event.cmd, event.msg
		});
		
		oz.viewer.addEventListener("OZPrintCommand", function(event){
			//event.msg, event.code, event.reportname, event.printername, event.printcopy, event.printedpage, event.printrange, event.username, event.drivername, event.printpagesrange
		});
		
		oz.viewer.addEventListener("OZExportCommand", function(event){
			//event.code, event.path, event.filename, event.pagecount, event.filepaths
		});

		oz.viewer.addEventListener("OZProgressCommand", function(event){
			//event.step, event.state, event.reportname
			//append("OZProgressCommand=", "step="+event.step+", state="+event.state+", reportname="+event.reportname);
		});
		
		oz.viewer.addEventListener("OZCommand", function(event){
			//event.code, event.args
		});
		
		oz.viewer.addEventListener("OZErrorCommand", function(event){
			//event.code, event.message, event.detailmessage, event.reportname
		});
		
		oz.viewer.addEventListener("OZExitCommand", function(){
		});
		
		oz.viewer.addEventListener("OZMailCommand", function(event){
			//event.code
		});
		
		oz.viewer.addEventListener("OZUserActionCommand", function(event){
			//event.type, event.attr
			var MyObj = eval('(' + event.attr + ')');
		   if(event.type == "Tree") {
			   var reportcnt = oz.viewer.getInformation("REPORT_COUNT");
			   var currentReportIdx = oz.viewer.getInformation("CURRENT_REPORT_INDEX");
			   var displayname = oz.viewer.getInformation("DISPLAYNAME_AT=" + i);
			   var txt = displayname + "&nbsp;&nbsp;&nbsp;&nbsp;" + currentReportIdx + "/" + reportcnt; 
			   document.getElementById('reportdisplayedname1').innerHTML = txt;
			   document.getElementById('reportdisplayedname2').innerHTML = txt;
		   }
		});
		
		oz.viewer.addEventListener("OZLinkCommand", function(event){
			//event.docIndex, event.componentname, event.usertag, event.uservalue
		});
		
		oz.viewer.addEventListener("OZBankBookPrintCommand", function(event){
			//event.datas
		});
		
		oz.viewer.addEventListener("OZPageChangeCommand", function(event){
			//event.docindex
		});
		
		oz.viewer.addEventListener("OZPageBindCommand", function(event){
			//event.docindex, event.pagecount
		});
		
		oz.viewer.addEventListener("OZReportChangeCommand", function(event){
			//event.docindex
			//append("OZReportChangeCommand : ", "docindex="+event.docindex);
		});
		
		oz.viewer.addEventListener("OZReportChangeCommand", function(event){
			//event.docindex
		});
		
		oz.viewer.addEventListener("OZUserEvent", function(event){
			//event.param1, event.param2, event.param3
			event.result=event.param1+event.param2+event.param3; //userEvent sample
		});
		
		oz.viewer.addEventListener("OZWillChangeIndex_Paging", function(event){
			//event.newIndex, event.oldIndex
			event.result=true; //OZWillChangeIndex_Paging sample
		});
		
		oz.viewer.addEventListener("OZEFormInputEventCommand", function(event){
			//event.docindex, event.formid, event.eventname
		});
		
		oz.viewer.addEventListener("OZExportMemoryStreamCallBack", function(event){
			//event.outputdata
			if(event.outputdata == "{}" ){ 
				showmsg("Fail to Export Memory Stream ");
			}else{
				//caseobj save
				var inputjsonall = oz.viewer.getInformation("INPUT_JSON_ALL").replace(/'/gi,"\'");
				//var caseObj = JSON.parse(oz.storage.get(category_acceptcase, casekey));
	
				//caseObj.ozddata = JSON.parse(inputjsonall); //should put json object cuz oz json can involve sub object
				//var casejson = JSON.stringify(caseObj).replace(/\\/gi,"").replace(/'/gi,"\'");
				//oz.storage.put(category_acceptcase, casekey, casejson);
				//console.debug("inputjsonall="+inputjsonall);
				//console.debug("event.outputdata="+event.outputdata);
				var obj = eval('(' + event.outputdata + ')');
				var value = null;
				var file_name = "";
				var formdata = new FormData();
				var index = 1;
				for(var key in obj){
					//file_name = key;
					value = obj[key];
					//console.debug("file_name="+key);
					formdata.append("file_name_"+index, key.replace("/sdcard/",""));
					formdata.append("file_stream_"+index, value);
					index++;
				}
				formdata.append("ozdata="+inputjsonall);
				
				/*$.ajax({
					type : "POST",
					url : "./reportSave.jsp",
					data : param,
					async : false,
					success : "",
					error : function(request, status, error) {
						if (request.status != '0') {
							alert("code : " + request.status + "\r\nmessage : "	+ request.reponseText + "\r\nerror : " + error);
						}
					}
				});*/
				$.ajax({
					type : "POST",
					url : "./upload-file",
					data : formdata,
					dataType: 'text',
					processData: false,
					contentType: false,
					success : function(data){
					},
					error : function(request, status, error) {
						if (status == 'error') {
							alert(request.responseText);
						}
					}
				});
			}
		});
		
		oz.service.push.addEventListener("messageArrived", function(event){
			//console.debug("push => command="+event.command+" ,message="+event.message);
			shownotimsg(event.command,event.message);
		});
		
		oz.navigator.menu.setVisible(false);
		oz.navigator.addEventListener("action",function(event) {
			//alert("event.button => " + event.button);
			switch(event.button) {
			case "home":
				console.debug("home onclick.....1");
				break;
			case "back":
				if(oz.viewer.isVisible()) {
					//can't press back button when oz viewer appeared
					event.handled = true;
					kendoAlert("Apro e-Report", "Please select Back button on top");			
					break;
				}
				console.debug("back onclick.....1");
				break;
			case "forward":
				//alert("forward onclick.....1");
//				if(!oz.viewer.isVisible()) {
//					oz.viewer.setVisible(true);
//					event.handled = true;
//				}
				console.debug("forward onclick.....1");
				break;
			case "refresh":
				console.debug("refresh onclick.....1");
				break;
			case "menu":
				kendoAlert("Hey Now!", "Important Message For You");			
				break;
			}
		});
		if(typeof initializer == 'function') initializer(); 
		else (0,eval)(initializer);
	});
}

function b64(s) {
	  var key = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=';

	  var i = 0, len = s.length,
	      c1, c2, c3,
	      e1, e2, e3, e4,
	      result = [];
	 
	  while (i < len) {
	    c1 = s.charCodeAt(i++);
	    c2 = s.charCodeAt(i++);
	    c3 = s.charCodeAt(i++);
	   
	    e1 = c1 >> 2;
	    e2 = ((c1 & 3) << 4) | (c2 >> 4);
	    e3 = ((c2 & 15) << 2) | (c3 >> 6);
	    e4 = c3 & 63;
	   
	    if (isNaN(c2)) {
	      e3 = e4 = 64;
	    } else if (isNaN(c3)) {
	      e4 = 64;
	    }
	   
	    result.push(e1, e2, e3, e4);
	  }
	 
	  return result.map(function (e) { return key.charAt(e); }).join('');
}

/* category setting */
var category_root = "/hvac";
var category_acceptcase = category_root + "/caserepository";
var category_submitozd = category_root + "/submitozdrepository";

/* local repository */
var localrepository = "local://localrepository/";
var repository_catetory = "hvac/";
var aprolocalrepository = localrepository + repository_catetory;


function escapejson (val) {
    if (typeof(val)!="string") return val;
    return val      
        .replace(/[\\]/g, '\\\\')
        .replace(/[\/]/g, '\\/')
        .replace(/[\b]/g, '\\b')
        .replace(/[\f]/g, '\\f')
        .replace(/[\n]/g, '\\n')
        .replace(/[\r]/g, '\\r')
        .replace(/[\t]/g, '\\t')
        .replace(/[\"]/g, '\\"')
        .replace(/\\'/g, "\\'"); 
}

